	<a href="flik1.html"><div class="button"> <p> Flik1 </p> </div></a>
	<a href="flik2.html"><div class="button"> <p> Flik2</p> </div></a>
	<a href="flik3.html"><div class="button"><p>Flik3</p></div></a>
	<a href="flik4.html"><div class="button"><p>Flik4</p></div></a>
	