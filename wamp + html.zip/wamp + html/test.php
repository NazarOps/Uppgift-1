<!DOCTYPE html>
<html>
<title>Gameshop</title>
<head>
<link rel="Stylesheet" type="text/css" href="css.css">
</head>


<body>

<div class="navigation">
	<a href="test.html"><div class="button"> <p> Hem </p> </div></a>
	<a href="flik2.html"><div class="button"> <p> Support</p> </div></a>
	<a href="flik3.html"><div class="button"><p>Registrera dig</p></div></a>
	<a href="flik4.html"><div class="button"><p>Om oss</p></div></a>
	
</div> 
<!-- slut på navigation -->


<div class="main">


<center><h1>Rea</h1></center>

</div>


<div class="footer">




</div>

</div>
</body>

</html>