<!DOCTYPE html>
<html>
<title>Gameshop</title>
<head>
<link rel="Stylesheet" type="text/css" href="css.css">
</head>


<body>

<div class="navigation">
	<?php
	include("navigation.php");
	?>
</div> 
<!-- slut på navigation -->


<div class="main">


<center><h1>Rea</h1></center>

</div>


<div class="footer">




</div>

</div>
</body>

</html>