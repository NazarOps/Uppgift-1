	<a href="test.html"><div class="button"> <p> Hem </p> </div></a>
	<a href="flik2.html"><div class="button"> <p> Support</p> </div></a>
	<a href="flik3.html"><div class="button"><p>Registrera dig</p></div></a>
	<a href="flik4.html"><div class="button"><p>Om oss</p></div></a>
	